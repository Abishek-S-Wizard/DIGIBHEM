<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title> Terms & Conditions </title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">  

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="lib/animate/animate.css">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />
    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
 <!-- Title box -->
 <div class="container-fluid bg-dark px-0">
    <div class="row gx-0">
        <div class="col-lg-3 bg-dark d-none d-lg-block">
            <a href="index.php" class="navbar-brand w-100 h-100 m-0 p-0 d-flex align-items-center justify-content-center">
                <h1 class="m-0 text-primary text-uppercase">KGA HOTEL </h1>
            </a>
        </div>
        <div class="col-lg-9">
            <div class="row gx-0 bg-white d-none d-lg-flex">
                <div class="col-lg-7 px-5 text-start">
                    <div class="h-100 d-inline-flex align-items-center py-2 me-4">
                        <i class="fa fa-envelope text-primary me-2"></i>
                        <p class="mb-0">kgahotel07@gmail.com</p>
                    </div>
                    <div class="h-100 d-inline-flex align-items-center py-2">
                        <i class="fa fa-phone-alt text-primary me-2"></i>
                        <p class="mb-0">+04324 232556</p>
                    </div>
                </div>
                <div class="col-lg-5 px-5 text-end">
                    <div class="d-inline-flex align-items-center py-2">
                        <a class="me-3" href="https://www.facebook.com/chettinadtech.ac.in/"><i class="fab fa-facebook-f"></i></a>
                        <a class="me-3" href=""><i class="fab fa-twitter"></i></a>
                        <a class="me-3" href="https://www.instagram.com/chettinadclg/"><i class="fab fa-instagram"></i></a>
                        <a class="" href="https://www.youtube.com/channel/UCA9C45i5LsOj7SghvS0eHoA"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
            </div>
            <nav class="navbar navbar-expand-lg bg-dark navbar-dark p-3 p-lg-0">
                <a href="index.php" class="navbar-brand d-block d-lg-none">
                    <h1 class="m-0 text-primary text-uppercase">Hotelier</h1>
                </a>
                <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                    <div class="navbar-nav mr-auto py-0">
                        <a href="index.php" class="nav-item nav-link active">Home</a>
                        <a href="about.php" class="nav-item nav-link">About</a>
                        <a href="booking.php" class="nav-item nav-link">Room Booking</a>
                        <a href="room.php" class="nav-item nav-link">Rooms</a>
                        <a href="ok.php" class="nav-item nav-link">Stats</a>
                        <div class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                            <div class="dropdown-menu rounded-0 m-0">
                                <a href="booking.php" class="dropdown-item">Booking</a>
                                <a href="team.php" class="dropdown-item">Our Team</a>
                               
                            </div>
                        </div>
                        <a href="contact.php" class="nav-item nav-link">Contact</a>
                    </div>
                <a href="signin.php" class="nav-item nav-link">SIGN IN</a>    
             </div>
            </nav>
        </div>
    </div>
</div>
<!-- Title box -->
<div class="pr">
<center><h1 class="mb-4"> <span class="text-primary text-uppercase"> <u style="color: darkblue;">Terms & Conditions</u></span></h1></center>
<hr >
<h4 style="color: rgb(232, 10, 10);  padding-left: 55px;"><b>1. Scope of Service </b></h4><br>
   <h5 style="color: blueviolet;  padding-left: 55px;"> 1.1. These terms and conditions are subject to occasional changes and apply to all our services that are directly or indirectly provided (i.e. via third parties) via the internet, on mobile devices, by email or by telephone.</h5>
    <h5 style="color: blueviolet;  padding-left: 55px;">1.2. By using our website, you confirm that you have read, understood and agree to these terms and conditions, as well as the privacy policy, including the use of cookies.</h5>
<hr>
<h4 style="color: rgb(198, 0, 0);  padding-left: 55px;"><b>2. Services and Contract</b></h4><br>
<h5 style="color: blueviolet; padding-left: 55px;">2.1. On the trivago website, you have the ability to compare third party services via the trivago system.</h5>
<h5 style="color: blueviolet;  padding-left: 55px;">2.2. In addition, for some hotels, users have the possibility of booking the selected hotel through a direct connection to the hotel booking sites (third parties) (‘trivago Express Booking’). As a result, the booking will be made directly on the hotel booking site and not on the trivago sites. In such cases, trivago is not the travel operator or the contractual party for the user, but only an agent providing the technical connection to the hotel booking site of a third party. By making a booking on the website of the third party, users agree to be bound by the terms and conditions of that booking site. These terms and conditions can be viewed on the website of the third party. Once a booking is made on the website of a third party, a contract is concluded between the booking site and the user, and therefore no contract is concluded between the user and trivago. trivago is no contractual party to the hotel booking and all and any claims of the user under the hotel reservation are to be asserted against the third party (the booking site) and not against trivago.
</h5>
<h5 style="color: blueviolet;  padding-left: 55px;">2.3. This agreement is not affected by any other agreements between the hotel and users.</h5>
<hr>
<h4 style="color: rgb(243, 0, 0);  padding-left: 55px;"><b>3.Website design </b></h4><br>
  <h5 style="color: blueviolet;  padding-left: 55px;">We use a test method to improve website design. An original version of our website is tested against a modified version to find out which is more effective.</h5>
    <h5 style="color: blueviolet;  padding-left: 55px;">When you visit our website, technical information is evaluated based on a pixel and a tracking ID. The evaluation is not personal but group related. The legal basis for this is our legitimate interest in the optimization of our website.</h5>
</div>
<div style = "margin-left:10%;" class = "container">
		<div class = "panel panel-default">
			<div class = "panel-body">
				<center><strong><h3>RULES AND REGULATION</h3></strong></center>
				<br />
			<p>Bills must be settled on presentation, personal cheques are not accepted.</p>
				<br />
				<strong><h4 style = "color:#ff0000;">1. Tariff</h4></strong>
				<p>The tariff is for the room only and is exclusive of any government taxes applicable Meals and other services are available at extra cost . To know your room tariff, please contact the Duty Manager, guest registration forms must be signed on arrivals. </p>
				<br />
				<strong><h4 style = "color:#ff0000;">2. Settlement of Bills</h4></strong>
				<p>Bills must be settled on presentation, personal cheques are not accepted.</p>
				<br 
	            <strong><h4 style = "color:#ff0000;">3. Company's Lien on Guest's Luggage and Belongings</h4></strong>
				<p>In the case of default in payment of dues by a guest, the management shall have the linen on their luggage and belongings, and be entitled to detain the same and to sell or auction such property at any time without reference to the guest. The net sale proceeds will be appropriate towards the amount due by the guest without prejudice to the management's rights to adopt such further recovery proceedings as my be required.</p>
				<br />
				<strong><h4 style = "color:#ff0000;">4. Check-in</h4></strong>
				<p>Please present your ID card, Passport or Temporary Residence Card upon Check-in. By Law visitors must present personal documents for hotel records. These documents will be returned upon departure.</p>
				<br />
				<strong><h4 style = "color:#ff0000;">5. Departure</h4></strong>
				<p>Check out time is ( mention your checkout time here ) please inform the reception if you wish to retain your room beyond this time. Extension will be given depending on the availability . If the room is available, normal tariff will be charged. On failure of the guest to vacate the room on expiry or period the management shall have the right to remove the guest and his/her belongings from the room occupied by the Guest.</p>
				<br />
				<strong><h4 style = "color:#ff0000;">6. Luggage Storage</h4></strong>
				<p>Subject to availability of the storage space, the guest can store luggage in the luggage room, at the guest's sole risk as to loss or damage from any cause, Luggage may not be stored for period of over 30 days.</p>
				<br />
				<strong><h4 style = "color:#ff0000;">7. Pets</h4></strong>
				<p>Mention your policy for Pets ( allowed or not- allowed ) (Allow us to make separate arrangements. )</p>
				<br />
				<strong><h4 style = "color:#ff0000;">8. Hazardous Goods</h4></strong>
				<p>Bringing goods and / or storing of raw or exposed cinema films, or any other article of a combustible or hazardous nature and / or prohibited goods and / or goods of objectionable nature is prohibited.</p>
				<br />
				<strong><h4 style = "color:#ff0000;">9. Damage to Property</h4></strong>
				<p>The guest will be held responsible for any loss or damage to the hotel property caused by themselves, their guests or any person for whom they are responsible.</p>
				<br />
				<strong><h4 style = "color:#ff0000;">10. Management's Rights</h4></strong>
				<p>It is agreed that the guest will conduct him/ herself in a respectable manner and will not cause any nuisance or annoyance within the hotel premise.</p>
				<br />
				<strong><h4 style = "color:#ff0000;">11. Relation between Management and Guest</h4></strong>
				<p>Nothing herein above shall continue or be deemed to constitute, or create any tenancy or sub-tenancy , or any other right to interact in the hotel premises or any part of portion thereof, in favour of any Guest or resident or visitor, and the Management shall always be deemed to be in full and absolute possession of the whole of the hotel premises.</p>
				<br />
				<strong><h4 style = "color:#ff0000;">12. Government rules and regulations and application of laws</h4></strong>
				<p>Guest are requested to observe , abide by confirm to and be bound by all applicable acts and laws and Government rules and regulations in force from time to time.</p>
				<br />
			</div>
		</div>
    
</div>
<style>
    .pr{
        font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
    }
    

</style>
<hr>
    <div class="thr">
</div>
<style>
.thr{
   background-color: black;
   width: 100%;
   height: 120px;   

}
</style>
<!-- About box -->
<!-- Last box -->
 <div class="container-fluid bg-dark text-light footer wow fadeIn" data-wow-delay="0.1s">
    <div class="container pb-5">
        <div class="row g-5">
         
            <div class="col-md-6 col-lg-3">
                <h6 class="section-title text-start text-primary text-uppercase mb-4">Contact</h6>
                <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>Big Street, Chennai, India</p>
                <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+04324 232556</p>
                <p class="mb-2"><i class="fa fa-envelope me-3"></i>kgahotel07@gmail.com</p>
                <div class="d-flex pt-2">
                    <a class="btn btn-outline-light btn-social" href="https://chettinadtech.ac.in/"><i class="fab fa-twitter"></i></a>
                    <a class="btn btn-outline-light btn-social" href="https://www.facebook.com/chettinadtech.ac.in/"><i class="fab fa-facebook-f"></i></a>
                    <a class="btn btn-outline-light btn-social" href="https://www.youtube.com/channel/UCA9C45i5LsOj7SghvS0eHoA"><i class="fab fa-youtube"></i></a>
                    <a class="btn btn-outline-light btn-social" href="https://www.instagram.com/chettinadclg/"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
            
            <div class="col-lg-5 col-md-12">
                <div class="row gy-5 g-4">
                    <div class="col-md-6">
                        <h6 class="section-title text-start text-primary text-uppercase mb-4">Company</h6>
                        <a class="btn btn-link" href="about.php">About Us</a>
                        <a class="btn btn-link" href="contact.php">Contact Us</a>
                        <a class="btn btn-link" href="privacy.php">Privacy Policy</a>
                        <a class="btn btn-link" href="terms and condition.php">Terms & Condition</a>
                        
                    </div>
                    <div class="col-md-6">
                        <h6 class="section-title text-start text-primary text-uppercase mb-4">Services</h6>
                        <a class="btn btn-link" href="food.php">Food & Restaurant</a>
                        <a class="btn btn-link" href="room.php">Hotel & Rooms</a>
                        <a class="btn btn-link" href="sports.php">Sports & Gaming</a>
                        <a class="btn btn-link" href="fitness.php">GYM & Yoga</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="copyright">
            <div class="row">
                <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                    &copy; KGA Hotel, All Right Reserved. 
                     Designed By <a href="https://chettinadtech.ac.in/">Chettinadtech</a>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <div class="footer-menu">
                        <a href="index.php">Home</a>
                        <a href="">Cookies</a>
                        <a href="contact.php">Help</a>
                        <a href="contact.php">FQAs</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <br>
</div>
<!-- Last box -->



    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>


</body>
</html>