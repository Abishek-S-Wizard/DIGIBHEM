<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title> contact </title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">  

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="lib/animate/animate.css">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />
    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
 <!-- Title box -->
 <div class="container-fluid bg-dark px-0">
    <div class="row gx-0">
        <div class="col-lg-3 bg-dark d-none d-lg-block">
            <a href="index.php" class="navbar-brand w-100 h-100 m-0 p-0 d-flex align-items-center justify-content-center">
                <h1 class="m-0 text-primary text-uppercase">KGA HOTEL </h1>
            </a>
        </div>
        <div class="col-lg-9">
            <div class="row gx-0 bg-white d-none d-lg-flex">
                <div class="col-lg-7 px-5 text-start">
                    <div class="h-100 d-inline-flex align-items-center py-2 me-4">
                        <i class="fa fa-envelope text-primary me-2"></i>
                        <p class="mb-0">kgahotel07@gmail.com</p>
                    </div>
                    <div class="h-100 d-inline-flex align-items-center py-2">
                        <i class="fa fa-phone-alt text-primary me-2"></i>
                        <p class="mb-0">+04324 232556</p>
                    </div>
                </div>
                <div class="col-lg-5 px-5 text-end">
                    <div class="d-inline-flex align-items-center py-2">
                        <a class="me-3" href="https://www.facebook.com/chettinadtech.ac.in/"><i class="fab fa-facebook-f"></i></a>
                        <a class="me-3" href=""><i class="fab fa-twitter"></i></a>
                        <a class="me-3" href="https://www.instagram.com/chettinadclg/"><i class="fab fa-instagram"></i></a>
                        <a class="" href="https://www.youtube.com/channel/UCA9C45i5LsOj7SghvS0eHoA"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
            </div>
            <nav class="navbar navbar-expand-lg bg-dark navbar-dark p-3 p-lg-0">
                <a href="index.php" class="navbar-brand d-block d-lg-none">
                    <h1 class="m-0 text-primary text-uppercase">Hotelier</h1>
                </a>
                <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                    <div class="navbar-nav mr-auto py-0">
                        <a href="index.php" class="nav-item nav-link active">Home</a>
                        <a href="about.php" class="nav-item nav-link">About</a>
                        <a href="booking.php" class="nav-item nav-link">Room Booking</a>
                        <a href="room.php" class="nav-item nav-link">Rooms</a>
                        <a href="ok.php" class="nav-item nav-link">Stats</a>
                        <div class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                            <div class="dropdown-menu rounded-0 m-0">
                                <a href="booking.php" class="dropdown-item">Booking</a>
                                <a href="team.php" class="dropdown-item">Our Team</a>
                               
                            </div>
                        </div>
                        <a href="contact.php" class="nav-item nav-link">Contact</a>
                    </div>
                <a href="signin.php" class="nav-item nav-link">SIGN IN</a>    
             </div>
            </nav>
        </div>
    </div>
</div>
<!-- Title box -->
<div class="text-center wow fadeInUp" data-wow-delay="0.1s">
            <h6 class="section-title text-center text-primary text-uppercase">Our Hotel</h6>
            <h1 class="mb-5">Explore Our <span class="text-primary text-uppercase">Contact us page</span></h1>
</div>
<center>
<div class="us"> 

<form action="" method="post"> 
    <div class="form-shape"> 
        <label for="query"> 
            Type of Query 
        </label> 
        <select name="myQuery" id="query"> 
            <option value="sel" selected> 
                Select 
            </option> 
            <option value="ord"> 
                Order related Issues 
            </option> 
            <option value="Site"> 
                Site related Issues 
            </option> 
            <option value="fed"> 
                Complaint related Issues 
            </option> 
            <option value="others"> 
                Others 
            </option> 
        </select> 
    </div> 
    <div class="form-shape"> 
        <label for="name">Name</label> 
        <input type="text" name="myName"
            id="name"
            placeholder="Enter your Name"> 
    </div> 
    <div class="form-shape"> 
        <label for="email">Email-Id</label> 
        <input type="email" name="myEmail"
            id="email"
            placeholder="Enter your email"> 
    </div> 
    <div class="form-shape"> 
        <label for="pho">Phone Number</label> 
        <input type="phone" name="myPhone"
            id="pho"
            placeholder="Enter your Phone no"> 
    </div> 
    <div id="radio"> 
        Are you already stayed in our Hotel?
        Yes <input type="radio" name="eligible"> 
        No <input type="radio" name="eligible"> 
    </div> 
    <div class="form-shape"> 
        <label for="message"> 
            Ellaborate your query 
        </label> 
        <textarea name="mesg" id="message"
            cols="30" rows="10"> 
        </textarea> 
    </div> 
    <a href="contact1.php"><button class="book-button">submit</button></a> 
    <input type="reset" value="Reset"> 
</form> 
</div>
</center> 
<style>
    .us{
    font-family: Georgia, 'Times New Roman', Times, serif;

    }

</style>

<hr>
<div class="thr">
</div>
<style>
.thr{
   background-color: black;
   width: 100%;
   height: 120px;   

}
</style>
<!-- About box -->
<!-- Last box -->
 <div class="container-fluid bg-dark text-light footer wow fadeIn" data-wow-delay="0.1s">
    <div class="container pb-5">
        <div class="row g-5">
         
            <div class="col-md-6 col-lg-3">
                <h6 class="section-title text-start text-primary text-uppercase mb-4">Contact</h6>
                <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>Big Street, Chennai, India</p>
                <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+04324 232556</p>
                <p class="mb-2"><i class="fa fa-envelope me-3"></i>kgahotel07@gmail.com</p>
                <div class="d-flex pt-2">
                    <a class="btn btn-outline-light btn-social" href="https://chettinadtech.ac.in/"><i class="fab fa-twitter"></i></a>
                    <a class="btn btn-outline-light btn-social" href="https://www.facebook.com/chettinadtech.ac.in/"><i class="fab fa-facebook-f"></i></a>
                    <a class="btn btn-outline-light btn-social" href="https://www.youtube.com/channel/UCA9C45i5LsOj7SghvS0eHoA"><i class="fab fa-youtube"></i></a>
                    <a class="btn btn-outline-light btn-social" href="https://www.instagram.com/chettinadclg/"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
            
            <div class="col-lg-5 col-md-12">
                <div class="row gy-5 g-4">
                    <div class="col-md-6">
                        <h6 class="section-title text-start text-primary text-uppercase mb-4">Company</h6>
                        <a class="btn btn-link" href="about.php">About Us</a>
                        <a class="btn btn-link" href="contact.php">Contact Us</a>
                        <a class="btn btn-link" href="privacy.php">Privacy Policy</a>
                        <a class="btn btn-link" href="terms and condition.php">Terms & Condition</a>
                        
                    </div>
                    <div class="col-md-6">
                        <h6 class="section-title text-start text-primary text-uppercase mb-4">Services</h6>
                        <a class="btn btn-link" href="food.php">Food & Restaurant</a>
                        <a class="btn btn-link" href="room.php">Hotel & Rooms</a>
                        <a class="btn btn-link" href="sports.php">Sports & Gaming</a>
                        <a class="btn btn-link" href="fitness.php">GYM & Yoga</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="copyright">
            <div class="row">
                <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                    &copy; KGA Hotel, All Right Reserved. 
                     Designed By <a href="https://chettinadtech.ac.in/">Chettinadtech</a>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <div class="footer-menu">
                        <a href="index.php">Home</a>
                        <a href="">Cookies</a>
                        <a href="contact.php">Help</a>
                        <a href="contact.php">FQAs</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <br>
</div>
<!-- Last box -->

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>




</body>
</html>