<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title> KGA Hotelier  Hotel </title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">  

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="lib/animate/animate.css">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />
    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
 <!-- Title box -->
 <div class="container-fluid bg-dark px-0">
    <div class="row gx-0">
        <div class="col-lg-3 bg-dark d-none d-lg-block">
            <a href="index.php" class="navbar-brand w-100 h-100 m-0 p-0 d-flex align-items-center justify-content-center">
                <h1 class="m-0 text-primary text-uppercase">KGA HOTEL </h1>
            </a>
        </div>
        <div class="col-lg-9">
            <div class="row gx-0 bg-white d-none d-lg-flex">
                <div class="col-lg-7 px-5 text-start">
                    <div class="h-100 d-inline-flex align-items-center py-2 me-4">
                        <i class="fa fa-envelope text-primary me-2"></i>
                        <p class="mb-0">kgahotel07@gmail.com</p>
                    </div>
                    <div class="h-100 d-inline-flex align-items-center py-2">
                        <i class="fa fa-phone-alt text-primary me-2"></i>
                        <p class="mb-0">+04324 232556</p>
                    </div>
                </div>
                <div class="col-lg-5 px-5 text-end">
                    <div class="d-inline-flex align-items-center py-2">
                        <a class="me-3" href="https://www.facebook.com/chettinadtech.ac.in/"><i class="fab fa-facebook-f"></i></a>
                        <a class="me-3" href=""><i class="fab fa-twitter"></i></a>
                        <a class="me-3" href="https://www.instagram.com/chettinadclg/"><i class="fab fa-instagram"></i></a>
                        <a class="" href="https://www.youtube.com/channel/UCA9C45i5LsOj7SghvS0eHoA"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
            </div>
            <nav class="navbar navbar-expand-lg bg-dark navbar-dark p-3 p-lg-0">
                <a href="index.php" class="navbar-brand d-block d-lg-none">
                    <h1 class="m-0 text-primary text-uppercase">Hotelier</h1>
                </a>
                <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                    <div class="navbar-nav mr-auto py-0">
                        <a href="index.php" class="nav-item nav-link active">Home</a>
                        <a href="about.php" class="nav-item nav-link">About</a>
                        <a href="booking.php" class="nav-item nav-link">Room Booking</a>
                        <a href="room.php" class="nav-item nav-link">Rooms</a>
                        <a href="ok.php" class="nav-item nav-link">Stats</a>
                        <div class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                            <div class="dropdown-menu rounded-0 m-0">
                                <a href="booking.php" class="dropdown-item">Booking</a>
                                <a href="team.php" class="dropdown-item">Our Team</a>
                               
                            </div>
                        </div>
                        <a href="contact.php" class="nav-item nav-link">Contact</a>
                    </div>
                <a href="signin.php" class="nav-item nav-link">SIGN IN</a>    
             </div>
            </nav>
        </div>
    </div>
</div>
<!-- Title box -->

<!-- GYM -->
<div class="text-center wow fadeInUp" data-wow-delay="0.1s">
            <h6 class="section-title text-center text-primary text-uppercase">Our Hotel</h6>
            <h1 class="mb-5">Explore Our <span class="text-primary text-uppercase">Fitness</span></h1>
</div>
    <center><h1 class="u-f1"><u style="color: blue;">GYM & YOGA</u></h1></center>

    <div class="c-layout-wrapper">
		<div class="c-layout-inner-wrapper">
			<div class="c-rte">
						<figure class="m-image c-rte__figure js-lightbox-single u-1/1 u-1/2-s  u-float--right">

<span class="o-fit  image-56628f82-1363-47d3-bed4-7e9e87282c99">
	<picture>
		
		<img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoGBxQUExYUFBQXFxYYGSEZGRkZGCAhHxwcHB8ZGRwfIh8iIioiIR0nHyEYJDUjJysuMTEyHCE2OzYwOiowMS4BCwsLDw4PHBERHTAnISguMDAyMDA2MjAwMDAwMDAwMDAwMDAyMDAwMjAwMDIwMDAwMDAwMDAwMTAwMDAwODAwMP/AABEIAMIBAwMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAEBQMGAAIHAQj/xABJEAACAQIEAwUEBwYEBAYBBQABAhEAAwQSITEFQVEGImFxgRMykaEHI0JSscHRFGJykuHwFTOC8RaissIkRGODk9LiFzRDU1T/xAAaAQADAQEBAQAAAAAAAAAAAAABAgMABAUG/8QALxEAAgIBAwMCBQMEAwAAAAAAAAECEQMSITEEQVETcSIyYYGhBZGxFDNC8BVS0f/aAAwDAQACEQMRAD8A5KEU7H+9hWNhum36f1qP2NZ7M9aT7jGzWI3/AL6/pUZSt1RuWvr6141txqVPnFFBNSlWHsFhpvO/K3bJ9W0Hymq5mq/dhsBlw+Y73mn/AEg5V+ec0mV1AI0t4UDP+6AP5Vk/81b4bDFVBDHQfkW/Kpgsq375PwLT+AopkhV6QWPloo/BvjXJZqIcEbo0BGsyY10gfGZrLrsrEMDlBju7kBc59JmjcMhAPUAD/UZc/wDMRW2KSXy+J+en4Bf5qCYaIXxo2jLyA6TqfDp+FMcLl0y7bT+H+1BPYDMOhafnP4A1rh7IJB2ks/oxCj5A0bAN2UMZ5Dry/rQt/CExppy8BsP19ahxFzImYsQFBdteSiT+M+lc8Xt1jo99TrM5FJ8umnlNPCLlwFnSr9oCFGioN+Unc+lcu7YcVGIvzbZfZWxkSZEwZLbR3j8gKh4t2sxV5PZ3bhyc1VQobzgSfLakolj1PQfn0q2PHp3YGb2ftj9w7EHYzyqSx7VgAg0617hLQDdSQdttBMeNTWQyjMvu9OnpVGzFl7H8Vez9VfabR2IElDv/AC/hV9tcOV1DIQ6nUMDIPqK5ZZ4laI7zAGprHaNbZ+qe4D/6ZIn4RUZQt2HY6inCD09amXhIA1089Irlb9o8Q/urfYc8ztH40d2Vxd44lfaW8quCslpM+8vPqI9aV46VhOg3bFke9dSRzBB+Qr1L2HaAbqgjYkEekkailtzDGd/Cg3w8c/Gp3Zh1e4lhrZgEv1yDT4mKgHHlObJZ90A947gzyA5RG9KHw4mI6j41JhQA2X7wKj176/PMKFmJMR2gxAzZcgGwGTbpuTQ17iF59TcfUSADA+AgcxW11JExtE1pbTuT0OX4ww/MelaxSEW2JmthhzG/hUi71uFoWMAdocCLmGuAnZc+n7sMfwqgrat/dnzJ9dorqVlAe6djKnyO9cxxFlbbNbLSysVMdQSv5VfC9mgM8zJ9xP5ayo1dOprKtuLZCMR1UfD9K9/aQd1+dWTE/R/j0JzYW5p0KH8Gpdf7OYlD3sNfH/tMfmBS6o+RbQrLoeo+dE8Kvol1Szdw6MI5HQnnqND6V6/DHHvWri+aMPyqG5h1G5g0zaaoai4/8NLcZVVhH2jA93rVnt4RVhUACiAo6KBC/P8AOua4HiWIsgC3ecAbDcfAyIoux2pxqkAurAbFkH5RXP6UvJjoa4caxtsPIaVtfALR0gH02H8xJ9KotjtriAO+ltug1WPPeR4aUThu3JBGewCB0uak8zquvl86HpSCXvh+HOgbQL32/EfMAelRSSxeOWnrIH5GquPpAHe+ouQTqcyyenw10qfDdu7B95LqbfYB5aDQ7DcnnQ9OQxZMvvaaAEeg0PyzD4VLh7fhqAB6nl86U4fthg2UA3gs75gwP4eXwqZ+2OCRCxvqdZhZLH0A8/lQ0S8G2APpE4iLWGKz3r31a/w7sf5dP9QrlmcVbeNcetYy5maQAIRCp7q9SRI8z+lBLw3DHUXE8s8T/NvV4PQqaZtNiWzZL6SY6nn5D86LFkAZQARzj8zz/Cmj8IttqttW/hY/9rR8qBu4EWyQReT1kfAqPxo60waWgNLcONwNefVWHOtsFZQwWLbaQf0ovD2nBzW3ZnEFR7MToeRDGoVuta/zC1thOnswxOpM6sANTEeFHVeyNpaV0E4jA231UZW8RKnz5jzFb4fGFD7NrYVuW0HyNQ2+Jzs2Ib+EIv4Bq3fDvcB/8LiXnZmZ2jxgWwKFPuCxgjXY1KqP3mFY7qpB/abYYa6HYjUUswvAsTv+yFj/AOorCI30LCjMNg8Q3uWcIPEexP8A3NWpeTHR8FiUv2luIwYMJkbSNCPjXl6yDsDr/uKr3ZTE4nDufbtZNptwpAKH7yhVAPQienTW1jjGDP8A5m2sfeJWPjFRcN9hhddtE7KdRI8x/UVFfwrbqNRt+K/l8aZHjeATfFWJGo749R/So7navho/8zb9Ax8BstFQZtjR8PLaQFuCR4E6j4NofPwoaxgmlkP2h02ZTp8swrd+23Dl0F5m1+zacgfLairnanAMub9pQf6Wzfy5Z+VL6cjbANvAk6xpMVMnDD0Ne3u3XDlUkXiY0yrbeT4iQBHjUd3t7gxZN5ReuKDlbKiypO2YFhAPI7eulH05eDbBNrhpHL50o4p2K9pdLotrv6nMgJzbHefP41Fc+lLC/ZsXj5lB+BNL8Z9KjkEW8Oinq9xm+QVfxpo45rg1xHVvsOQB3lP/ALSD/trKouI7eY1mLe3KzyVYA8taym9Ofk1x8HeuFYe4qLbvEFomRrtpr4nQz1r3F4WD0HXz6VLjMa9oqWsk24ALq40kgCBufkPGlfG+K37bElUFuRDDWN5J2J0B5c9Nq4cyjCNt7klDVshlgscbYIYkgbD++VQniVi4HW97HOglvaZe7Pmo2+dQXcQc4gDKSuWNT3yRtGgAgyejSKD4twq1lZmxAS6c2QRBK8gQxBbuhp2mfCqY5yS23QvxLZFH4nhw918Nh8PZdxcuM5ayvcWQV75AAUDU+YHhWvaTszatvl9gFy2++ZZVYgd+4CJAUFkGu/rFMMNjCeJZAGFsljoCNWVpBA1kHTTwqxX7lo4j2t+6pCK6Dn3iqAaDuhg2Y6a0mt7U9jenLffuVJuxWFFh/ea8mYFhcIUMkyApBlYiNZJnaRSrF9k0t4D9pcutx7/s7Slhqp0GZQpIM6b1euI4fCixee0zOyI7AQVDu456abAA+NIO32KDYGyzHLcULcKg6i5kgjWJE6SNZTbnVITmpJN3e3JTHGXLNP8A9NFZDctXmKb5yoKxofe0nQzO1C2Po/BbK2LtpFwpLLAldyCWEiNdKuOCawcF7EYrP9SFRTICsF0B8ZqLg5SxdUXzZax7R8jMJYMstmXwYlf5YjSs5Si1b2+pSXwt1uIL30XXk1tX7VwNABGYT05Hz9Kx/opxVy3vZcMJDK+uvMSororcQwth1Ib2KRmjKQhLzqRsGjmIPe6UVhu0mEjLbuqQupCawN5gbDxrpSjy2T9TY5K30VYy2uVbAcbmLia/8wJ+FL7/ANHGLXfCv/pBP/TNdtHarCFsgvqW6az8IqO72vwSnK2IQEcjIP4UU4viX5Msifg4Rc7J4i2O9ZvppqcrAeO4oW/hrtsGHuDQ7kV9BYXj9nEubdi4GC6sRPwGlJfpDwYNnPsQCB0gqZE7Drr0qeSWlWtysNL52OS8Be1buE32ZdABlSdAY1013GoofHY1bmID2gCVFxs5VpBAuMBuB0P51ceE2LIsO962jNcCW1GVT7OCFXfWdS5I/KrjiuB4ezi7C28NY9ldbXLbSUZLdw7R7rrGm0pPOkxQjKTn34Gnkaio9jjS8cxZ3dvh+prR8bim/wD5LnxX9K+gsVbw9oj6m0AdJ9msE77xpEH4jxphbtoBKqonXQD9KukrpUQUk9j5uGGxrbG8fIn8qIvcJxN0EXMPd9pyuIjAt/GAIb+IQeuavpAXBFRDFhtjtTOl3NZ822uxeNYf/tr587b/AJip1+j/AB3LC3f/AIj+lfRxdudavdMbVrMfO57AcR//AMt3+QD8xUqfRnxI/wDln/mQf99d/IB3NePeynTWNzFC65CcJT6J+JHewR53bf8A96mP0PY+JKIPA3V/Ku527+bWhb/FAsjI522U8+c0XJLuA4mfofx/3bPrd/Ramwv0SY5SYu4dZBVouOZU7gjJqNtK7Ut6QIbTx360DiMTl0VczdOX9ND61OWTbZm2OP2PoivEH6+wMu/vmD5QDWL9El3QtiLQQ/bCEj8R46115EW6pDJ3iZPKY8tfStLrWWGQWzAMZiJ56jXX8qi8uRdxGcuX6HCRP7Zb/wDhP/3rK6DiOM28x77+i15Q/qJef4F1oq/HO1yOWTILkd+5mvREQIylGUNp7swNZO9CYa/lJOEtreN9TdUtnzF1BAUIoACwfekiWOgiqhZe05ZbjXHt20SFQZRmJVbgI56yOegonG38Q7yuc2gSqot1ma2gIGVWXS24QXO6TEK2kRIeGL+bn6/uWjNNnQuHdoipZAVW8wU9+ciM4ByAK0GDIMfrW3FcNe+pvtkNor9Yj9xCSYTNOZ8skNC5dAZqh8J4u7Ye2UUW1tMxFwANEoZzA8x3ZaY752NZhsZdxF62DeBS2CmZ3aGJAJEIDmzSBmIMyJJpYY3BNe9DWnyNsPxm41truVEW7Cg5Y1HdcW8wlW3kk7giTFD2uImyRZDL7QGVGYHKxMhZIIY7AmIEERQ/D+F3LyXLLMqlCEXMpPs7mbMSSrbEsSDqNZ6VXrBPegtccACe9qBJBzEwOUedb0k90PNVVlww/Fh/kMr/ALQrgspcg+1nQkg6r3hpt1HVf23wt7Ef5bNcS2ZuET7PN3iMmkMArMZE6H4rcDhr63XVLGYggGM2hzZgQyxpoT1pjg8XfW3cUtdzBmBLOTmnNHio0ZTB1PrR0qD1J7kacdzyzfxNhDcR7gzgHL7S4Mg3zblQTpoR86OtuM2d2xF660qkxBJmLiLHvAnRiDMGBIrSzdQ2SbyMxJALO66dPdhjziD60rfEmzcAsXWK5Sq3IZTquUwTl1JJMCdIpYylPZiynJ/cu9zGXLH1zhgod1ZQ+Ziph1zhoCiQRm19yF3pdiuNZrRdnRVtMAbKsfaMQQNWidDzOo1pJizcKorHMwAPInvBYMzB2jwiKW4aTmgrmDAMFAJAbQ66mNj0nxoaLuwenfL+wxXtI+RWCOQCRdAulXB1ymR3miTuY0jxq2dn+y1y7atYi5jibZm4Ldy2IKjNoWkEiNTpyqlWLttHvtkzDIQohve0bSQNo8oJ3q49m8WtywqLfylcMLYQD3GJl8zR/ltlQaHTXrTfL2/37jqMUrr2LJ2fV7FnDorW1uPJYkaMoBhzzDMAp9D0qwccshsPdDAH6tp6e6TVE4HxK5cZTdvXB7JTIbITyz227sQsAgqSYEnerNhOItfwruLmdWW6ZgCUi4E035CnhJSbTNF2VYcBSCt5Ga4ty3AYSCjOIJGoywQZ6giouzeJspi1toVKozM7rbhmcg2yJ07isTEDXMegmyduM6qlyzpcGVIKt3wbluBAEkgmQBvJHOq32Pwl63iGFzJ7NUYrNtkYkZYZyVnMDmBjWazjoe31Jy2kvudCuvbYeychtjlJE9R4zpW2CNsyUPMhpJJkaEGTVBwmKt3HNy3LFLqCBoM5JBEdNtSTrTyxZITNlYjUudco33PPnzqX9Q74JrJbui1Kmh8dfShLMB4AO0/jQ3CsczOVcrkywAJkHSJmeXOj7iDMNR+u0fCuhTUoqSLxlqN8Q4ynSR0HP9KCtXH2jSdm3iTp+H9miruGT7UkR7s6bzMczPOpbLKR7q5eR/vamdtjUQ3r4CFjyFaWsASFJYrBBheg11O8nnQ3E8ICbf1rgFxIBgECWPLnR13Ei2I1IHISTG0+lBbfMZo0xVxl2UPvoBqBEgb7zNB4vFoEVXuFSCAwQHc/ZIGsf31o1eIqwzKwKga5TPy60BxLBZ7ouXMotKJMEg92WkwPI+hot2Kwa5fNuSrllMwM2vxPIQdddzUJ4kujCVDchrmY9CPMa+Fa4zAhBqrG2qli0E7d2FHMmZ6QT0oKxikfvlQbwINgDugoMuswB97Q+IqdWK7G2C4hasoVd4d2yga7xpO55HUn1qPiGNZVSVUTuS2/lI/SN6CdMOlwqDDn/NUMRJIY6Md9SRpBg7iKMxOJt5FzQbTDXctBIHPziDrSTTapAdsgWxaOuZDPRayvfZWOReNgIIiNI93lt6VlRr6Ao47g8DlZQ+RnBZ12IDj2K5XBE5PeBHnGtM/+JBh7Rw9tbT2RMOgbOmdcjG5qe9qdqW43GXVtBXs5iCxzrEwwYszRmBknNOkR61LgOD27igrcCXZVrYIhhqO6VJ72s9fnXVJpbz4E1NPYc43s9bRXZS72FLNlUgIRcGoGZgc4nLMGMo56Uv7JXLtm9ZYqgt30bRgWlV1AygnvSDAjc7EAVP2h/aBhSUdWsd5LttNQpL5nZdIVQQAonTQR0BvZsPhs9q4vdJTMGBuXALtwTGpFuAsHTUH1Ed4c3boumk7iOGxrX3v50W17XK73GLZEXIFBlSJJYJyG3pVUuIzXyjZltswZkmJyjpI7o1AB8as3BeLn2k3LrszZcwIILZTcaQRI0CyJ3zKKH7VW3XiCSAxdAQrEGFIOmaN9DrFCDcZNfQuoa0pMGWxiPa3hbzNaW+AuspJLakg7CJ0nY1txDi/1JtKqgH/UF9477yZMjbQazNPuI3QLb5Qod3uMye6bT6BgROoyy+878m0quO4W9q33mVXZwO8Drmt5421216ErWjJSe5smN1Udwm0rhmynKHs+0BcTBUSQeWoMj8q8JNx0ttBX6uCT3YALRqdB3SDRnF1AsYdkGVsqC4DzLdw6HrJ2+6Z21RYXEhsSoAYKEbNGrFMhkbDUEEj+laEdW/8AuwMkEpJIe4PFFBevJDd5wIEyoJVf3dxMDlFL0xpVvaAZXIEjQggHQyQQc0tpEedNOH4lUtKy5sgOWQBJO7aA5ve1IEajpFIOOswusVZWBE5lkjI2xnqNiN5mjGFt7DyapJsMuY1Stt0j2gWZWdA65TI0AMSpA+Ao/geGtXLGQZ0uEqS0nLlEllAPTutHWfKqjg8SFRwZgQBoNemk8t/71f4PC3EFm5mGW4oAfcqrsVJ6T5/no2SFHJJyZZuHYz2DNlyXbbMS/fliGOYZQPebKcpB2zH3eRGHxgsWA6m6loKoW0STlS4zZ2YIe8MoOv7w0GsrFtM1hrgKPa3Vcon2gBEnWZBU+YHpR3CIuq9s6lIcTAI9pcVWBJ5GJCqd43iox2Ycbp0x5e4smLNlQbih7pNtrrgPKENnCqYCAqsKAPtT46JeVLjXs1wq1m4zQ5b2ZV7a3AFJgAMIEaxFRJg8jAW19o3tWZAEAtn6tlCySdQufkC2x60DiuOHC3lT2Wdr9sygyMM7MAzxK7hMuXQHKIJpmtf5DOnx9R9wTB2bWe9IVLrAg3cvJmKwJiZiSelNsPc/akkO5SSH0aDB0AEDzn4UmwvFMKiW0Zbv1Y7kgPlMMS2W3mCnRuUwYnXVpwPtThiCWvKDnYS0qA2c6S0dVERzFaGNcMlGKWw9wiWkthcoWNTP4kkCvMPiFdlIYZcrHQiCZUAiDsdaA4jxKzdw9xxetFhacBrd0GAVk7HTUDrtXous2Hi0NSuUMQQuUtAIMSZBGoBFUfw1sWVDa6qGXie6I+dD4K2cmYcydPiKHxiD2NwvAPsyAE05NpPvaelF8OwxW2qiSIjUnMBMDvfa0jfXxNNtJmT+Fm19AXQRtJ+UfnXlywSSc0A8vPqZrDZJuAqGIEz3tvdgQToaS8CxGIvLeuZiSuIuW0XKsBFaIJjfTfyraPKM+ENHy2AXIWdpVO9lnSTuY01oGzb9tcze3Ypr9XlAnMIgsDOknQxv4UyuO4Bkwfsyknfopk+lKOIYi5hir28OpV7iodfZyWmMo72kzMgb0soO9uDN2HW1KZEt6AHQNpoukCdSJ10rMSyAqrWwGA7vcMDbYxGk0WENwZWWDGqlyCPEd30kaHxqM8LGUqVuEdPaTtG0kRsOnzNZ45GpHO+MJb9q9xW0Ud4Tsw0BWNNQG16zNQYS5iLqZlJYMrQjOTlBOWSCdDMHxirtxLA4G09sXrJVrrZEGXNmYkSIUnmRRn+CYYBl9kQGADAW2ggagaCK1SS4DSo55iO0Nu2xR7YLLoTtJryr5/wxgv8A+kfyN+lZS0v+v5Bpj5OGcGx6riUVLjNbYAQ/3mBUyswIzGNhoDTTG4uyouMts3WUHNKkHMsqBmmVC6mBrtJnaq4WyFYDKZylgWMAiM2gMTpOm+mlNFGYhUUkhSHRNWEyWYAiAfATlnrVpwTlZGUXaoacDVMWuS4l/OULtcV5QBT3R7MiGc6DxLTpTG3wu2MFeWwHDo0g3MrOST95U01gxroDrrSvgGFyYa5dyuru4W2S0EWxBOnmBrvppFMsZ2iTD4dVSWe4jKVG67KWJ5trpO8VGUk5aI+f4PVx9BKPTvNNUvP8Fc4RxIWr9s3gLygspJ1kt3RudcrbH+lMuNFjestfX/KbK5zAdxGBAKyTosCZ1mkWGxjpdOoLFSpL933oJPT49ak4hjRcnuiOUnYTl73KSec9KrKPxJnFGbSqzoS4T2l66GAGRWUmIlC0qM0ySyZdRES3WqzxPtAz3MPb9nmyRoN2gm25kg+9GhiR4Vphe1LFvaNbJLWVRmLECULd/uwdj12HpQHDMbaF9jcYIMrlX1Ms85fTf4zUoYnb1F551a0sY9or2ZLoK5TZZAQAe68uCoPMZSu/Q1WLOIK5hyGeNdSWGUgnmIAP6TVl7XIt24l2zdzB7CG4FJg3VBUesRPlzmktrCtAZkzEqQV2PgSTvy0Hxq8IKKpcEMk3J33Lp2Ss2msoQ6WnCoQCAQxc7QdYzRsRvVU7QW7jXrllVAGcu2Vp1aDE6AiSYHjrrW+Cwt14FyzKosJ3oIiY2ddROhJMUXgsLiLaEC0gb7JLAxtJ3Bk6ydzQpr3Dab4K82EuKSpLDkZVhHWRE8tqsXAeFLeVbTlUJAyF2cdySS3SJ7pBIgknkYGXgGJJPeWCwOpJj1AmKcrhcT7JbXcyKZgWwTqNRJGxMnkTJkmtJSYJxTXw/sNCpsWXRrFs22OdLoDqAxyJAOYlRyOmpiaKxeDN7D4e8igC1ef2qq0lAt1SqkBiNgZYgaDyoHgljEW7b2cx9k9soQ6qQJYEnUGeY9aZYt2YIpuuxAysVWM/ezd4AAaSQI2GlIsbTsCieYbi1i1iMttibVu5MtJOVbd0KBEBmk5QIMynPUqeMBbeJwl28mS61y4bozGRAVbdtZM90EAEGGYnUSSLBb4AL132jCJf20E6e01hsuuuu9MOIcIL3bb+ytOoQqysgjVg2kDTXWjGDW4FAAZkIVw4aT1nn3QNBI5+Mg6d3Iv7Jsi4Z7hKib10wYErmbcgxsD70QAfsiS8xnZzDlSBhApO7WnyHmOg5EjfmalwvZiwtuLL38OdTBIcZiS099X1zQf9K9BRSZtLoS9q0Q4e8WVZUCDlkySvL7JzE6mI0O6qo04VhhbsWgoKE2xJVim6gTmB0OoOY7SrN3jlqbtD2XxLW3X29p1YqokEN7wy8xtpyMd47kknYfguNtKv/h0bKI+ruCdM8HvBRuRGp1e6xkkUrboRp0KuOcSv28M7rfugkaSzMCSyzCvOmug3VSASXBFNMNxG+qgm+Pdkm5bSBCiScoU5QSGbUwA6DMymkfafC3TYNr9nuhiykjISAoYGTkzGJzwAeTtq1ypOKYwQos3EzRm1JVk0YiQSAGWM2oyrlIGtw1o2xoqqH13jmItlnK2zlU7e0Q91cwUgs6zmJnkoNtjGYQo7IdpHFtlK3ABdLE27irPtAHdmzR3FZlBbMIzL1mknEb95bNxXSFKFdJ0zL3V3mMs93cqyO2qkDXguKa2j5I1uE6idUCqDB0aASCD3VVs5krVexSi1cQ7Q4hbTfsvtEcDMxxCBiAWCDvLcMFWzMQwMCNAINC8E4tiBaw7cQxKn/wASrhjAyqA47zCB78Dat+E4i06MLxKofeYkyoJCgSdWY6Brv2wq8jS7t3gkXFWLCZfZ/VZQ1zKO/cYvLkd1T7Ia6/gKnGblKlwv5LPGowuXL49joA7QWbhi3iLN0TGlxCRoRplYMDmj0ovB4y6JzLnWRBWQwESZEwwmdRrEaHeue3cJnEtatuCrNMAQqjIz973FAGW45l7g7y8qHbh9lCSMP7OQWypNuVMMVBB+qVYLJdbvOMywNJpuQpFr7R4wXcdw9Ne6xuGYMd1j4GQVEgxVh/xy0dritvsGG2hnQga8yQNq4jcdrmIYriCUtPPthnJyIEEIHJaWYkQTEknQbXHCY3EX7T3cNiL+VSItXbdpybcgMoi3Jc8hmjUa6UHJJ0OscpR1JbIv3t3P2nHh7S1pWVzHG43HM7MP8PYE6G+VW5/rUN3WGxHhWVqEo5ldT6zM2omYnNoQco/varJgeIM1q3asW3S57jOxE5QyuOQ7sBgfMzNT8a7UYcSMNaVmAj2rWxA5QoO7eJ0HQ1Vjx27Mho9N+s9QaaeNyQcTiprU3XevBb+M4slo0hekan7R5DWmWE4ThLluzccm6ouS2sBlynulYn38gyz1quYK77YKVkltMo3zdK6HwTg9vDWxacgM31jGdM22UCdY05RXDixSbpco+r/Vupxw6aOmXwtLZd15AsDw21iFuriLKpZB7gAVQqx9mAMp+FUFuDMzrkQBFOYqJ11nXx5V1jD3DctFrZ0IKkaTHMj40oxWHjcV04ozSuR8u82LKlLHuil/4TdDZsukEQfGOtRJ2cdh93n7qnf1q23LZ5ma9RB0qiVAuxLh+BMYzXC2gGkLoBGwFMLPZu3oCZbkCTRt7HW7IzQGYGI0gHKWGYdNNvKqJg7dy9fd2DliSxae9SSnTaKwxalZ0DD9nI5CmOH4GR0+H9KN7OsTYXOWJGhLbzofWJA600DR5df9tarBOaTRGdQk4sXYfgw6UYnDVHIfCiFvf2Na9N2m9OQjyRI/2Ja1/ZkHIfCthjekN/C0n4f1rxsQpE5GnpGU/BtKLhXcynfYlsWxNH2rVAWLmtMbLTUxyUWQa3WwOlYtSqKYQFvcPRtxNeqoXaR8qLr2KKRrEmP7QWLTZbl5FIBLZoIUDUyeVJz224dcJtsbNySYAa2QRy0Lbnp4VYb/AGew7Fz7MIXEObZKZgZHeykZtzvSLiX0cYW6uWBGXKJtWyQNhD5Q8jqWNZRV/ECT8IX421wu7YulbQsPlYLmVrQzRodMoYTHUGqpxbjfDMMfZ4e7iHGhb2eRrcgl8vfUkjMToDGvnRfFfoXI1s380bBgAQPn+VJcP2FTDuf2rD37i+EgDxm3m+BqihF8NCa5LlE+NW5iLGGt2s+bEXTcjmLdvVQeWgZTpAGTSABTTifZnFXL1i6tv2tsojwQjEBUYHuOVU9+4IEnYnlVk7LfsYULbXK6q1tA+aVtySAM3gR3tzFO+DreVEU/ZRU7pkGABOoFc0YNfn+TrnO1XsUa7fe0PrLN+3s5ZrLuQRorMRK3byju6kJkjcrFRLxay31a3EOoGQXMxzbhddbt0GHtMYRNF0yiekcU4mLFp712MiCTpqdYAHiSQK5V2h7V3sTc0AtqD3VT3o8W3mujF00sj24ODqOpjhW+78CC3i3LXy7Pme4WzOsM0s8yAImMu2k1dcJNjBW1ALe23CPleApclG+ywgGeUaaxVQvXNfxp5wpfa2DauzkJkEHZhqGjVTB6g7V0Zf0/vF7kcP6t/jKO3uQXr5J7ou3BAh7CEW2ECCJEk9TzbMedZR//AAdcuEv/AIhGYlo9lcWJJOyXQg9KyuX0p+Pwdfrw8/k5d+x3n+wx89B86ks8KIINxkUcwXEnw02rsdvB8Mae5htOZAHzNBXMFw0z7LDW7p/dQBR5t3RVNcV/i/3Bom+6XsiucD7WLayWrNqyQmqpbtOzTEFs0zmjnVju4t79u3intspVisMQmRZZSSGYE6EnzUdKgfEWrK5bVq2jbsbY28JOp000pdjccZAmTckQecCYM8jUM+SVKUUtnex1dPh9RvHq3aaV8WWfsrjWFsWSMtwLqCsgldyORLAT61txK9m31/0gD5ClvBMdb7pVWFxQF13AnNDHnsRI609xid45bZI3HdnfXp8q5+jWrVzTbe5s+J4IxjNJSWzS4+jEYcf7a1vZtlmCqJYnb9Z5Ub+1sPs/kab8OshV9owGZhpI1C7/AD0Pwrp6hLDj1NkcMnlnpSKt2m7LgsPZvkcgG433oBC9392THn46Rdn+zhsqWJ9qxMEwBAnQiTp40+4hcAk7sTA8SxhfxA9K2v3RbsAaZmYesa/p8a8jHkllkk3sz2pRjix6kt0G4PDlUCrrqxJYnmSehoq3g25tHkP1J/Ck+HxfU/35mKZWbxYbE+PT8vnXrRm4xUV2PHnFTk5PlhtvCJ9ok+uv/LFbMlsfZE9YH560tve2AnVh+7AI8YnbyJPhUJukkgkzznf1B1q0YuX+RGUlH/EZXL42zUv4txBLFtrtwwqiTPPoBPMnQV4bsDUgDxqs/SRdBwTZZPfXQTB1jy3g6UXiilbMsspOiocU7e4y4/cdrSZoy29DAO0xO3P4Vevo57YPiALV0ktllSRrpAMnnOprkWDuANt+Ovw59DXSPorwJNxLzmVNt8vKCHCwdzsT/e0m1Fouk5JnTrd0jn8aIs326T5VHYCjYev++tFqxouSJqLJEY8xHrUgoe9iFQZnYKOpOlYuLUiQcwOxGo+O1ZBCKyhTijyr1cX1FGgWTsKivWgRrXoxKnqK2JB50rQUxOmEVWMCJpjZWBXht61ICOVAYqX0qWXbB92IFxWeT9kSfMmY2rlStGoHyNXn6Ve1NsMMMHBKGXAYSW5DXoJ6anwqg2+KWm+8PMfnqPnXqdJKMY1Jo8broSlO4psKwlsMdTB+Xx5etOsEGURt1nSGEQfwBjcERsQIeB4RW1IkHQMI0Ppz8DHrU/GsC4tRm7quiGNZV5KgeEBtOQJ610Tmoq2cmLG5ypG9njF2O6yxJiRykx8qynOF7L9wZXQrGh1H4Vlcv9d0/n8Hf/xnVeEUm7xpremRSeiBDHw0Fef4vibhEqcs/aPmN4NW3hnY+3bhna5dI3BARR+E+s0+w1gD3ERR+6Nf+UD8a5HPEuE3+DtWPM+Wl+TmjcRZPfvW1PgCxHwpZiL9hmDO166w2IER5aiPhXXcTwpX1uIoHko/GW+dIe0nA8Oqd1RPQITPqdK3rpfLFL8hWB3bk/4Klge0Kqy/VnLzLNLR4fAVYuBcTutYDNdue8QFXQAHYTIk/GqxicOtvvXJQQSFkBjHQDYbanrzr0doHsplbumZFtDGUcgxM69dJ8eVT1Skq7eyLPSne7fltsvHDuEEsHvZvZzMMxJJ8Qdlp5jsWDoDXP8Asr2vuXb3snPdcHKTuGiYMQIInWBrFW7DoW2nTcdOtfN/qc82vRJ7dvY9nocWNw1x+/uQ4l81xByBzE+QMfOteOXoNpZ+xm5/a05eVT4y1CsqsoOpeTqdNFXlM6nyrMdhbTtbZgY9ntJHM8vOa6/0zBJNL7i/qOaHp7dtjTC31ERE+gn4S1NbOIbbl5HT1Y/lSm1bRfcAFT2b8c/Xc/Ovbl08krPDj1EW6HDXTG8+pP4QKguBD75AjXkCPKNfnQRxBiWPxYf9K6GoCWM5Qx9Mo/X4VHdF9mP+F4BGBuaFZhe6RPU66npQvaZVfJZ1BcxKoGAmQMwJ0Umd9DFOsJZyW0Qj3V189z85qIWe8WkzEekzt1pk6ditbUhBhewuBWM1hGYblZWT1IBgT0pvhuDpZBayISJK690b6aSeutGi3rFFYJdSPCPjQpN2xlJxTSF1riCjz8dB8dQfjUhxZPUeI/U0pt3AdoI2lTU9vw/v0ro0JcHNrbCUQj3WI9dPgZX4AViWgDOXKebW+7PmJg+p9KjW/Bjc9ADPwEzRiWHOpAQdWOvwB/Eig3XIVue2nP3g3mIPy0Pwqa0S2wJ/vrtW9jBrzBfxbQfy8/gfOp2c7TMcl5fp6kVNyKJHiYb7xjwFbqqjYAeJ3rUSNzlHz/T8a9DxsI8Tv+v4Uthowgnl8f0qn/Sjx+5h8NFg/WODL/dQQCQfvEkAb89txbGuA8yx+Q/L8TVD7fcFxGMeBcS3bXYSTmidDHuyddjy6VlKMd5BcJy2jycVxDNJLySdZJ1nz51FYuwQdacY3gt+67qlosLbZGyHMM2+msnToKdcB7J+2UErlXZmPM/ujn+HrVYfG6iSm9Cuex72cx4BGVsjxzG8a7fa8vzgi+9veHG3gZ2c3lcxy0ZVXxiR6k1XMH2YYXTZwzh2UZu9tbMkZmYQNNe6JJkSBEm4dsbDtwx1uPmuW7aEtEB2t5SzczJgmPHnTSlKtPYSEIOWtcnnBr6vZtsTkOWCoMwV7p3HhWVHweyLlm24jvKDvWV5OiXg971IeQ9mRdc1uPKf+Zt/hQf+K2hu0+bx/wBEz61SwcbcM+x9mp+3edQPPQlj6A0VbwE+9fuMf3FVF/5sxPnpTyyyi90kQh08JK02w7iPbvDW8wzgspIyokGRI1LTp4xVR4l24xOJYrYUwPWB1JPdHnpRXGez9i3bu3sqtcAL/WMWE7nuiAZql4niTvAJhRsqgAD0GnSuvE1NWjizQljlTGj3kRvaXn9re3AUnIp31O7GeW3nSrF3muMWPOtbCEn3C3ht+W1McJgLjbKqDqBJ+JmPSK6o4pS4RyzywjyyDhTutxSgJYMCoAkyDNdcPE40QctWI19B+dUrgvC/Z+6IPMnf/anTYu3b/wAy6Aek6/Detk6HHKUZ5Em1+wMfW5NLhBtJ/uE3HtISWGvWNfjTmwtu7btPnAXJBOkCCZkzpqaqmL7QWQpIVn9IHz1+VCYbjBaCqIk9BmPxOnyoZVFtOMqa8Ipi1Ri4yjae+77l0xVlFjJcVwddOXrt86GXEryOb+HX8NKr5Y3ILgMBr3zIHjGw9KNtXJ0LMw6DQfkCPjQ9elXP1Yj6dN3x9EMbmJYfdU9CZb+VZketG8H+uvImViB3mZjAgRrlnrA2G9JbVxSwth7VskxBdRHxgD4GrvwjBJh0yhszNqznmengvSoSk5O2XhFRVIZFtTWqjWtS3KtmTSgOe54Ut0n5VPwo6E+NLOOXWSwcmrGco6kwB86rnZjtZeuSrOJAnRV5ctqnOajVlIYZTTrsMFwyuSQhVp9/NBPTacw8G08Knw1ldmuPdjkgCj1YbH/UPKlgxKMxzHOZnINQJ1jKNAPFqZ2LrkcrY9Gb/wCq/wDNVFKS7kXFPsNbPdWe5aTwj5k6T6HzqW1d5qpP7zSB8+98AB40tw15ZlAbjfeJkD/WdAPBfhRFy4QM1y4FXoDlHq259I8qxqD2vCYdix+6o/Iax/EYrZXaOVtR5Ex/0j50DZxDRFpAq9WEDzC+8fWPOszqkG62dt9tPRdhHXfxrADLd0H/ACwWP3zMfzHUj+EEeVe3SPtnMfugaeo/UmlmI4qTMd1efWKqXBeKOuKuliT7YQkeBmT4BQaWcnFpd2UxwUk23sh3xjGiy/tsReyIPdtg8vKl1viVzFd423tWGOW2o0uXNASxP2EiNtTPLnthMVZOOSw9oFmUn2jatOpGpGg0NPeI8Rs2FzNoxGg3MdAPzqWi3S3Z0rIkk3sqI+FcAsYdAVtqkawJJk7mTLE+Jqv8SV8TiHtYYhbaQLrgEQ8arm6xlMLzJBO9QcS7RXb7BUlE5ye83w2HlTXhGNVECKqoBsFECuvH02SHxPa/93ODL1WPJ8K3p89vsNeD8Jt4ZAlsdMzc2j8h0pX2w4N+0oSjsjgET9kruQw6eNNUxYO/PaOfgBUeOtkj6zRdys6AdWPPy2HjvTN6eRUtWyE/AsLi7Ni3bUyFGhVLkGSTpGka8qyrHbxxgZbTEcj3RPoYI9aypWvA+iXk4td7UXDrlA8S3+9Cv2jvnRW+A/M0qbF2xznyH9itDxT7qgeJ/QV0Lpunjz/6TfV9VLjb8BV5Ll4zcYnwJP4VNawaW9WKjzgUFYW9dMZ8o8P0GvxppY7PJzLMepMfrPrVVnx49oRIyw5cnzyI/wDFbCbSx/dEfMxUF3tM+1tFXzJY/kKK/wCGrY3fL4bn4b0FiuDZfdkjqdPlvSS6mUu9Bh0kI9r9wa9xa/c9660dAYHwEURg3jmBQL2cp1qS2xGwrnm3Lk7cFQ4GFy8DpqfOmGGukAagD++ZpKk7kxR2FccgWPX+p/KkSHnKx3hr08p8T/XX4Uu7RdoGA9naaB9phv4gHp40BxDjRUFFInYkcvXn5ikouTp1plEi34J8PfYCeVWXsx25xGFyqO/ZG6NOg/dP2Y6beFVjEXQSANhpFeo8U4ln0TwbHpftrdtmQeR3B0lT4/iCDtTVl0kbH5elcs+izixW7asE92/aaPC5ZJykeaZgfJa6fcv5UzNC5R3pMf7idqm47jp7C7jOLyjXQgQv8RG/py8YrnXZC6PbFOeX0IkVZuKYprjPcBIlSF6RGnhVO7L63ladtD5VLqsdaV3Z19DkvW+xblDW4VVAHX7I9B/Si0xNtYzvnJ2U6z5IN/ma8F4c+7O0nunyb8jXjYcAlgAGPON663h8HnrN5D0xrtoq5B1bU+ijQep9K29vatsM0vcO095z5Ae6PIAUsdbhMZgidV1Y+p930E+Iqa1ft2O6BLHXKNXbxPP/AFMfWoOLXJZST4Gatdubn2S/dBBf+bUL6Zj0IpZibd22+W0/tzztt76g8/aDugR98SfvVIjvc99vZqdkU94+b8v9PxNTnHJZi3bSSdcqRPmfP7xgdTWUmuDOKfIl47xkW7ZVw1m4YA9osAydYYSh0nZpHOKC4K83C7m3mVRABkw2k+Rj8aL7ZYe5fw7i4RESEXYHkWbmfAQPOubcDFy0Wm4yDYHQhiOUHU+hEc6KjGUlJ9gubjBwiue50DEcRVcVZcRmW4o8YMA/ImveIzcuMW3n+xVTwfatHuBsTbGZTo6gkaFcsqDIgBhoNZ8NbLhsWl3vI4bnIM/GujpINSlKVbkOtmnGMI3sT2bUbVmM4jbsAFzqfdUbn+njSrjPaJbEokNd+S+fj4VWZe43tLpLFup1I6/ur068hGovlypbI5sWK92dN7PcZQgO0lz7oH4D8z6nTZqt3M0ucx3C/ZX9T4n0HM0HguIyxr6+HQdB/fjVnw2JLd1NPvOdcvgOreGw59DwStu2d8aSosftU5kfIVlA28NbAH1at4sJJ8ydzWUgxxRezgA7x+fX8PnU9jgtobDMfj8hTAWQIzn+Y/lzqZsaAIRSfMZR8N/lT2xaI7GGKjRQvn+g/pU7KBqz+QmB8tTQ928x1Z8o8BH9aEOKQbSx6j9Tv8awQ1sSAIUSPLKP1+VCX2YgkkKPh896hbFOdoUeGp+J/StLOGNx8qgu/Tcjx8B46CtVA54B7qodgWPXl8TvXgtHwHlqfif0p7h+zpPv3AvgozfPQfCaP/4XsCCTcuDozAL8FAMetTl1EF3OiHTZHvRWMBgTccJbUu/xjxJ2UecU74p2eC2ii3SbsSeSfwjn/q+VNhcS0MlsKqdFWB5nmfMmkvEONahLYz3GMKo1JNQeeUpfCjoXTQjG5spmNuMzd8DMO6YABldNY51qq5def4f1q/YbgNuzNy+EuX7n2N1QER6sevw61UuL4c2brW2tqRupiCVO2oPp6V1Qyxk6RxZMMoLU+BaNalUUTZNg7rcU+BDD560dgOEW3MhmyzuQBp0G88um9XjFydI5pTUVbLL9H+DHtbV52IWwgKgbu75mInkACJ6zVtxPEWf33JA2EmB8fxpDw6FUBYAHTajSwNdccSj7nJLK5E9/iC2xM6cxypP2Ew6NcuF5Vc2XTr8NorfithWQr1pPheI/skql1pJ91YJ9SdF5eNR6jC5pSTSrydHTdSsbcXFtNdjo+NwiW07rE6xlJBB9I8qrmI7SpbOSyC7/AHN7fo24PguaOgqtJcu3iS7EBtSoMk/xE6t66eFMsMUtjkOp8upqSyOMau35HcFKV1S8DJPa3oN1oG4VeR321Ajqcx5grTKzdt2h0k77lj8yx+JpHa4iz6Wxp95hp6DdvkPOjsFbAOYmW+82/pyA8BUZNvkrFJcDS2LlwzPs15c7hHrIUfPwFMLKW7SHZRzJ1JO2pOrHzk0lHFh7tsBm2JnujzPM+A+VeftGuZmzPyOwH8I5fM9SaAwTxrFs6wvdXxHePp9keevgKoPE8GSxIkn8h+Qq44zGj3QCzHp+JPIf2JpLjcKYMnfkNv78T8qyAyoNbCHbO3j7q+n2j56fxctbXtc+ZS3tDzBOb4jWnr4IA66f3yrLlgRAEDn1PmfyGnnvT2ChVaQL0d+u6jy5MfHbz3EtlixgSSfUk/malfCn8z0HnWIukDbYnm36L4c+fQEUZYFo2PmQfkp/7vh1q18IxEAKNABsNhVPwrjlTCxiTc7o/wAvn+//APh/1eW6NDJlu/xxfs27jryZTbAPiMxBjx57jSspVbvaDUfE/pWUA2Ug7URyXyP41lZRALG1uGda3WsrKYBFivdHnVkwChcNayiM2pjSTO561lZXP1PynX0fz/YbcL5VNj9hWVlecuT1exUeOuep2HOoOwn+bebmF0PMannXtZXbH+2ziyf3I+5Zrn+Yarn0h74fyb/trKypdN/dQ/V/2X9iuWqtuF9wV5WV7/S9z5nq+33GuC90UWfdrKyrsjHgVdqLhFloJGo2PjVawnvjzrKyuLqPmXsdvT/K/ce29hUeJ/zUHKCY8dNaysrmOgaYTeveLOfZnU+9G/KdqysoMKDuHe5W2M90+VZWUAkfBv8AKXx1PietSXNqysrPkwpb329B6d3So22rKyiYExeyfxflUIrKymFZs/uP/EB6dKZYasrKDCgyvKyspQn/2Q==" width="450px" height="300px" class="o-fit__image" loading="lazy" />
	</picture>
	<style>
		.image-56628f82-1363-47d3-bed4-7e9e87282c99 {
			padding-left: 33.77%;
			
		}
	</style>
</span>

		</figure>

<h5 style="color: darkblue; padding-left: 55px;"><span> |   There's no need to miss out on that workout. Just take a stroll to the gym or yoga class located within walking distance from the hotel. </span></h5>

			</div>
		</div>
	</div>



<hr>
   <center><h2>Hotel gym – Healthy mind in a healthy body</h2></center>
   <h5 style="color: darkgreen; padding-left: 55px;">1. Stay in shape, even when away from home. Keep up with your workout routine with free access to the Honour & Grace modern “Health Club”, located on the fourth floor of the Hotel. There you will find a full range of fitness equipment which will help you achieve your personal fitness goal, empower your body, recharge your mind and revitalize your spirit.</h5>
   <h5 style="color: darkgreen; padding-left: 55px;">2. Catering to all levels of ability and conditioning, our “Health Club’s” equipment consists of:</h5> 
   <h6 style="color:darkred; padding-left: 130px;">• cardiovascular machines <br>
    • multifunctional training machine <br>
    • weight station <br>
    • stretching area with mats <br>
    • balance balls <br>
    • jump ropes <br> </h6>
<hr>    
<marquee behavior="scroll" direction="right"> There are 8 Gyms available in our Hotel </marquee>
<hr>
 <center><h2><u style="color: blueviolet;">GYM Images</u></h2></center>   
<hr>
<center><img src="images/gym1.jfif" alt="">
    <h4 style="color: darkblue; margin-top: 10px; padding-right: 110px;"">GYM-1</h4></center>
<hr>
<center><img src="images/gym2.jfif" alt="">
    <h4 style="color: darkblue; margin-top: 10px; padding-right: 110px;"">GYM-2</h4></center>
<hr>
<center><img src="images/gym3.jfif" alt="">
    <h4 style="color: darkblue; margin-top: 10px; padding-right: 110px;"">GYM-3</h4></center>
<hr> 
<hr>
<center><img src="images/gym4.jfif" alt="">
    <h4 style="color: darkblue; margin-top: 10px; padding-right: 110px;"">GYM-4</h4></center>
<hr>
<center><img src="images/gym5.jfif" alt="">
    <h4 style="color: darkblue; margin-top: 10px; padding-right: 110px;"">GYM-5</h4></center>
<hr>
<center><img src="images/gym6.jfif" alt="">
    <h4 style="color: darkblue; margin-top: 10px; padding-right: 110px;"">GYM-6</h4></center>
<hr> 
<div class="thr">
</div>
<style>
.thr{
   background-color: black;
   width: 100%;
   height: 120px;   

}
</style>
<!-- About box -->
<!-- Last box -->
 <div class="container-fluid bg-dark text-light footer wow fadeIn" data-wow-delay="0.1s">
    <div class="container pb-5">
        <div class="row g-5">
         
            <div class="col-md-6 col-lg-3">
                <h6 class="section-title text-start text-primary text-uppercase mb-4">Contact</h6>
                <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>Big Street, Chennai, India</p>
                <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+04324 232556</p>
                <p class="mb-2"><i class="fa fa-envelope me-3"></i>kgahotel07@gmail.com</p>
                <div class="d-flex pt-2">
                    <a class="btn btn-outline-light btn-social" href="https://chettinadtech.ac.in/"><i class="fab fa-twitter"></i></a>
                    <a class="btn btn-outline-light btn-social" href="https://www.facebook.com/chettinadtech.ac.in/"><i class="fab fa-facebook-f"></i></a>
                    <a class="btn btn-outline-light btn-social" href="https://www.youtube.com/channel/UCA9C45i5LsOj7SghvS0eHoA"><i class="fab fa-youtube"></i></a>
                    <a class="btn btn-outline-light btn-social" href="https://www.instagram.com/chettinadclg/"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
            
            <div class="col-lg-5 col-md-12">
                <div class="row gy-5 g-4">
                    <div class="col-md-6">
                        <h6 class="section-title text-start text-primary text-uppercase mb-4">Company</h6>
                        <a class="btn btn-link" href="about.php">About Us</a>
                        <a class="btn btn-link" href="contact.php">Contact Us</a>
                        <a class="btn btn-link" href="privacy.php">Privacy Policy</a>
                        <a class="btn btn-link" href="terms and condition.php">Terms & Condition</a>
                        
                    </div>
                    <div class="col-md-6">
                        <h6 class="section-title text-start text-primary text-uppercase mb-4">Services</h6>
                        <a class="btn btn-link" href="food.php">Food & Restaurant</a>
                        <a class="btn btn-link" href="room.php">Hotels And Rooms</a>
                        <a class="btn btn-link" href="sports.php">Sports & Gaming</a>
                        <a class="btn btn-link" href="fitness.php">GYM & Yoga</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="copyright">
            <div class="row">
                <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                    &copy; KGA Hotel, All Right Reserved. 
                     Designed By <a href="https://chettinadtech.ac.in/">Chettinadtech</a>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <div class="footer-menu">
                        <a href="index.php">Home</a>
                        <a href="">Cookies</a>
                        <a href="contact.php">Help</a>
                        <a href="contact.php">FQAs</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <br>
</div>
<!-- Last box -->


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>



</body>
</html>